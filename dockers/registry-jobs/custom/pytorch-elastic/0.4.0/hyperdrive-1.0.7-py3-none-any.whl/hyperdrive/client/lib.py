"""Encapsulate HyperDrive functionality"""

import csv
import argparse
import logging
import time
import copy
from typing import List, Dict, Union, Tuple

import requests
from requests.exceptions import RequestException

import cpuinfo
import psutil
from os import environ
from py3nvml.py3nvml import nvmlInit, nvmlSystemGetDriverVersion, nvmlDeviceGetCount, nvmlDeviceGetHandleByIndex, \
                            nvmlDeviceGetMemoryInfo, nvmlDeviceGetName, nvmlShutdown, NVMLError

import uuid

class HyperDriveClientError(Exception):
    """ Base class for HyperDrive client exceptions """
    pass


class HyperDriveModelInheritance():
    """ Encapsulate information for hyperdrive-enabled model inheritance """

    def __init__(self, inheritance_args, logger):
        self.job_id = inheritance_args.hyperdrive_inherit_job_id
        self.experiment_id = inheritance_args.hyperdrive_inherit_experiment_id
        self.metric_name = inheritance_args.hyperdrive_inherit_metric_name
        self.metric_value = inheritance_args.hyperdrive_inherit_metric_value
        self.sequence_id = inheritance_args.hyperdrive_inherit_sequence_id
        self.checkpoint_path = inheritance_args.hyperdrive_model_checkpoint
        self.logger = logger

    def get_sequence_id(self) -> int:
        """ Return sequence id of inheritance model. """
        try:
            value = int(self.sequence_id) if self.sequence_id else 0
            return value if value else 0
        except ValueError:
            self.logger.warning("HyperDrive inheritance - Invalid sequence id {}".format(self.sequence_id))
            return 0

    def log_summary(self):
        self.logger.info("HyperDrive inheritance - ExperimentID:{0} JobID:{1}"
                    "MetricName:{2} MetricValue:{3} SequenceID:{4} CheckpointPath:{5}"
                    .format(self.experiment_id, self.job_id,
                            self.metric_name, self.metric_value,
                            self.sequence_id, self.checkpoint_path))


class HyperDriveClient():
    """ Class encapsulating HyperDrive logic. """
    
    SEQUENCE_NUMBER = "sequence_number"

    def __init__(self, args: List[str], retry_attempts=5, logger=None, generate_sequence_number=True):
        self.retry_attempts = retry_attempts
        self.failed_requests = []
        self.start_time = time.time()
        self.machine_info = None
        self.generate_sequence_number = generate_sequence_number
        self.session_id = str(uuid.uuid4())

        if logger is None:
            logging.basicConfig(
                format="%(asctime)s - %(name)s - %(levelname)s: %(message)s", level=logging.INFO)
            self.log = logging.getLogger(__name__)
        else:
            self.log = logger

        hyperdrive_parser = argparse.ArgumentParser(
            description='Process HyperDrive arguments')
        hyperdrive_parser.add_argument(
            '--hyperdrive_job_id', type=str, help='HyperDrive job id')
        hyperdrive_parser.add_argument(
            '--hyperdrive_metrics_uri', type=str, help='HyperDrive metrics uri')
        hyperdrive_parser.add_argument(
            '--hyperdrive_debug', action='store_true', help='Debug mode')

        hyperdrive_parser.add_argument('--hyperdrive_model_checkpoint', type=str, default=None,
                                       help='Model checkpoint path provided by HyperDrive')
        hyperdrive_parser.add_argument('--hyperdrive_inherit_job_id', type=str, default=None,
                                       help='Hyperdrive job id to inherit from (i.e., parent job)')
        hyperdrive_parser.add_argument('--hyperdrive_inherit_experiment_id', type=str, default=None,
                                       help='Hyperdrive experiment id to inherit from')
        hyperdrive_parser.add_argument('--hyperdrive_inherit_metric_name', type=str, default=None,
                                       help='Hyperdrive metric name that inheritance is based on')
        hyperdrive_parser.add_argument('--hyperdrive_inherit_metric_value', type=str, default=None,
                                       help='Hyperdrive metric value that inheritance is based on')
        hyperdrive_parser.add_argument('--hyperdrive_inherit_sequence_id', type=str, default=None,
                                       help='Hyperdrive sequence id for inheritance')

        hyperdrive_args, _ = hyperdrive_parser.parse_known_args(args)

        self.hyperdrive_job_id = hyperdrive_args.hyperdrive_job_id
        self.debug_mode = hyperdrive_args.hyperdrive_debug
        self.model_inheritance = HyperDriveModelInheritance(
            inheritance_args=hyperdrive_args,
            logger=self.log)
        self.hyperdrive_metrics_uri = hyperdrive_args.hyperdrive_metrics_uri
        self.next_metrics_sequence_id = self.model_inheritance.get_sequence_id() + 1

        if self.debug_mode:
            self.log.info("HyperDrive client initialization - Debug mode FirstSequenceId:{}"
                          .format(self.next_metrics_sequence_id))
        else:
            if not self.hyperdrive_metrics_uri and not self.hyperdrive_job_id:
                raise HyperDriveClientError("Missing both required arguments: hyperdrive_job_id and "
                                            "hyperdrive_metrics_uri")
            elif not self.hyperdrive_job_id:
                raise HyperDriveClientError(
                    "Missing required argument: hyperdrive_job_id")
            elif not self.hyperdrive_metrics_uri:
                raise HyperDriveClientError(
                    "Missing required argument: hyperdrive_metrics_uri")

            self.log.info("HyperDrive client initialization - JobID:{} URI:{} FirstSequenceId:{}"
                          .format(self.hyperdrive_job_id,
                                  self.hyperdrive_metrics_uri,
                                  self.next_metrics_sequence_id))

        try:
            self.machine_info = self._get_machine_info()
        except Exception:
            self.log.exception("Exception in getting machine info.")
            self.machine_info = None

        self.model_inheritance.log_summary()

    def get_model_checkpoint_path(self) -> str:
        """ Return model checkpoint path provided by HyperDrive (or None)"""

        return self.model_inheritance.checkpoint_path

    def _get_machine_info(self):
        """Get machine info in metric format"""
        gpu_info = self._get_gpu_info_by_nvml()

        machine_info = {
            "gpu": gpu_info,
            "cpu": self._get_cpu_info(),
            "memory": self._get_memory_info()
        }
        return machine_info

    def _get_memory_info(self) -> Dict:
        """Get memory info"""
        mem = psutil.virtual_memory()
        return {
            "total": mem.total,
            "available": mem.available
        }

    def _get_cpu_info(self) -> Dict:
        """Get CPU info"""
        cpu_info = cpuinfo.get_cpu_info()
        return {
            "brand": cpu_info["brand"],
            "cores": cpu_info["count"],
            "hz": cpu_info["hz_actual"]
        }

    def _get_gpu_info_by_nvml(self) -> Dict:
        """Get GPU info using nvml"""
        gpu_info_list = []
        driver_version = None
        try:
            nvmlInit()
            driver_version = nvmlSystemGetDriverVersion()
            deviceCount = nvmlDeviceGetCount()
            for i in range(deviceCount):
                handle = nvmlDeviceGetHandleByIndex(i)
                info = nvmlDeviceGetMemoryInfo(handle)
                gpu_info = {}
                gpu_info["memory_total"] = info.total
                gpu_info["memory_available"] = info.free
                gpu_info["name"] = nvmlDeviceGetName(handle)
                gpu_info_list.append(gpu_info)
            nvmlShutdown()
        except NVMLError as error:
            self.log.error("Error fetching GPU information using nvml: %s", error)
            return None

        result = {"driver_version" : driver_version,
                  "devices": gpu_info_list }

        if 'CUDA_VISIBLE_DEVICES' in environ:
            result["cuda_visible"] = environ['CUDA_VISIBLE_DEVICES']
        return result

    def _report_metric(self, metric_list: List) -> RequestException:
        self.log.info(metric_list)

        if self.debug_mode:
            return None

        try:
            requests.post(self.hyperdrive_metrics_uri, json=metric_list)
        except RequestException as err:
            return err
        return None

    def _try_add_property_to_metric(self, metric:Dict, key, value):
        valueKey = "value"
        if (valueKey in metric and key not in metric[valueKey]):
            metric[valueKey][key] = value

    def _add_run_time(self, metric:Dict):
        """ update metric by adding run time"""

        seconds = int(time.time() - self.start_time)
        self._try_add_property_to_metric(metric, "run_time_in_seconds", seconds)

    def _add_session_id(self, metric:Dict):
        """ update metric by adding session id"""
        self._try_add_property_to_metric(metric, "session_id", self.session_id)

    @staticmethod
    def _add_metric_sequence_number(old_metric: Dict, sequence_number:int) -> Dict:
        """ Return new metric dictionary with sequence_number added (or overwritting old sequence number)"""

        new_metric = copy.deepcopy(old_metric)

        new_metric[HyperDriveClient.SEQUENCE_NUMBER] = sequence_number

        return new_metric

    def _inject_metric_sequence_number(self, metric):
        """ Inject hyperdrive generated sequence number into metric.

            Arguments:
                metric: metrics data, provided by client script.

            Returns:
                Update metrics data with hyperdrive generated sequence number. 

            TODO (olruwase): Need to resolve whether clients should report metrics using a dict object or 
            a list containing one dict object. The latter is the case for the currently supported scripts, 
            the former is the case of report_metric api and unittests. This function currently handles both 
            cases and skips all other cases with a warning message. 
        """

        if isinstance(metric, List):
            new_metric = [ HyperDriveClient._add_metric_sequence_number(metric[0], self.next_metrics_sequence_id) ]
        elif isinstance(metric, Dict):
            new_metric = HyperDriveClient._add_metric_sequence_number(metric, self.next_metrics_sequence_id)
        else:
            self.log.warning("Failed to inject HyperDrive metric sequence into {}".format(metric))
            new_metric = metric

        self.next_metrics_sequence_id += 1

        return new_metric

    def report_metric(self, metric: Dict) -> Union[RequestException, None]:
        """ Report HyperDrive metrics

        Arguments:
            metric: json containing metric(s) to be reported to HyperDrive

        Returns:
            None if reporting was successful, otherwise a RequestException
        """

        if self.generate_sequence_number:
            metric = self._inject_metric_sequence_number(metric)

        # Attempt to report any previously failed metrics
        for _ in range(len(self.failed_requests)):
            request = self.failed_requests.pop(0)
            err = self._report_metric(request.metric)
            if err:
                request.failed_attempts += 1
                if request.failed_attempts >= self.retry_attempts:
                    raise HyperDriveClientError("Unable to send metrics to HyperDrive after %d failed attempts" %
                                                request.failed_attempts)
                self.failed_requests.append(request)

        if (metric is None):
            return None

        # backward compatible for list of metric
        metric_list = [metric] if not isinstance(metric, list) else metric
        if (len(metric_list) == 0):
            return None

        for m in metric_list:
            self._add_run_time(m)

        # add machine info to metric with sequence_number=0
        if self.machine_info is not None:
            if metric_list[0]["sequence_number"] != 0:
                dummy_metric = {"sequence_number": 0, "value": {}}
                metric_list.insert(0, dummy_metric)
            self._try_add_property_to_metric(metric_list[0], "machine_info", self.machine_info)
            self.machine_info = None

        for m in metric_list:
            self._add_session_id(m)

        # Report newest metric
        err = self._report_metric(metric_list)
        if err:
            self.log.error(
                "Error reporting metric to HyperDrive, will retry next time around. %s", err)
            self.failed_requests.append(MetricRequestAttempt(metric_list))

        return err


class MetricRequestAttempt():
    """ Class encapsulating individual metrics and number of failed reporting attempts """

    def __init__(self, metric):
        self.failed_attempts = 0
        self.metric = metric
