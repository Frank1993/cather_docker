import numpy as np
import random
from collections import OrderedDict
import logging
import torch
import torch.nn as nn
from torch.autograd import Variable

from mmod.simple_parser import save_prototxt


class CaffeData(nn.Module):
    def __init__(self, layer, phase):
        super(CaffeData, self).__init__()
        self.ltype = layer['type']
        net_info = OrderedDict()
        props = OrderedDict()
        props['name'] = 'temp network'
        net_info['props'] = props
        if 'include' in layer:
            if 'phase' in layer['include']:
                logging.info('CaffeData init phase = %s' % (layer['include']['phase']))
            layer.pop('include')
        net_info['layers'] = [layer]

        rand_val = random.random()
        protofile = '/tmp/.temp_data%f.prototxt' % rand_val
        save_prototxt(net_info, protofile)
        weightfile = '/tmp/.temp_data%f.caffemodel' % rand_val
        open(weightfile, 'w').close()

        import caffe
        caffe.set_mode_cpu()
        if phase == 'TRAIN':
            self.net = caffe.Net(protofile, weightfile, caffe.TRAIN)
        else:
            self.net = caffe.Net(protofile, weightfile, caffe.TEST)
        self.register_buffer('data', torch.zeros(1))
        self.register_buffer('label', torch.zeros(1))

    def extra_repr(self):
        """Extra information
        """
        return 'type={}'.format(
            self.ltype
        )

    def forward(self):
        self.net.forward()
        data = self.net.blobs['data'].data
        label = self.net.blobs['label'].data
        data = torch.from_numpy(data)
        label = torch.from_numpy(label)
        self.data.resize_(data.size()).copy_(data)
        self.label.resize_(label.size()).copy_(label)
        # print('dataloader data size = %s' % (str(self.data.size())))
        return Variable(self.data), Variable(self.label)

    @staticmethod
    def to_image(data, mean_value=None):
        """Convert a data to numpy array, correctign the image shape
        :param data: single data returned from forward
            e.g. if forward returns datas batch, data = datas[0]
        :param mean_value: subtracted mean
        """
        if mean_value is None:
            mean_value = [104, 117, 123]
        im = np.moveaxis(data.cpu().numpy(), 0, -1) + mean_value
        return im.astype(np.uint8)[:, :, (2, 1, 0)]
