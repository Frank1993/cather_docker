from __future__ import print_function
import os
import os.path as op
import argparse
import numpy as np
import math
import logging
import torch
import torch.nn as nn
from torch.autograd import Variable
from collections import OrderedDict

from mmod.utils import init_logging, cwd
from mmod.simple_parser import parse_prototxt, print_prototxt, read_model, read_blob
from mtorch.caffetorch import FCView, Eltwise, Scale, Crop, Slice, Concat, Permute, SoftmaxWithLoss, \
    Normalize, Flatten, Reshape, Accuracy, EuclideanLoss
from mtorch.region_target import RegionTarget
from mtorch.softmaxtree_loss import SoftmaxTreeWithLoss
from mtorch.caffedata import CaffeData


SUPPORTED_LAYERS = ['Data', 'TsvBoxData', 'AnnotatedData', 'Pooling', 'Eltwise', 'ReLU',
                    'Permute', 'Flatten', 'Slice', 'Concat', 'Softmax', 'SoftmaxWithLoss',
                    'Dropout', 'Reshape', 'Sigmoid', 'EuclideanLoss', 'RegionTarget', 'SoftmaxTreeWithLoss']


def _reshape(orig_dims, reshape_dims, axis=0, num_axes=-1):
    if num_axes == -1:
        num_axes = len(orig_dims[axis:])
    end_axis = axis + num_axes
    new_dims = list(orig_dims[:axis])
    count = np.prod(orig_dims[axis:end_axis])
    cur = 1
    for idx, d in enumerate(reshape_dims):
        if d == 0:
            d = orig_dims[axis + idx]
        elif d < 0:
            d = int(count / cur)
        new_dims.append(d)
        cur *= d
    new_dims += list(orig_dims[end_axis:])
    assert np.prod(orig_dims) == np.prod(new_dims), "Reshape: shape count: {} != {}".format(orig_dims, new_dims)

    return new_dims


class CaffeNet(nn.Module):
    def __init__(self, protofile, width=None, height=None, channels=None, omit_data_layer=False, phase='TRAIN'):
        super(CaffeNet, self).__init__()
        self.omit_data_layer = omit_data_layer
        self.phase = phase
        self.blobs = None
        self.output_loss = None
        self.output = None
        self.height = None
        self.width = None
        self.verbose = True
        self.forward_data_only = False
        self.forward_net_only = False
        self.blob_dims = dict()

        self.net_info = parse_prototxt(protofile)
        self.models = self.create_network(self.net_info, width, height, channels)
        for name, model in self.models.items():
            self.add_module(name, model)

        self.has_mean = False
        if 'mean_file' in self.net_info['props']:
            self.has_mean = True
            self.mean_file = self.net_info['props']['mean_file']
        self.targets = self.get_targets()

    def _blob_shape(self, btname):
        if not isinstance(btname, list):
            btname = [btname]
        shapes = ", ".join([
            "({})".format(
                " x".join([
                    "% 5d" % dim for dim in self.blob_dims[name]
                ]) if name in self.blob_dims else "...") for name in btname
        ])
        return shapes

    def _blob_size(self, btname):
        if not isinstance(btname, list):
            btname = [btname]
        shapes = ", ".join([
            "({})".format(
                " x".join([
                    "% 5d" % dim for dim in self.blobs[name].size()
                ]) if name in self.blobs else "...") for name in btname
        ])
        return shapes

    def set_network_targets(self, targets):
        self.targets = set(targets)

    def set_forward_data_only(self, flag):
        self.forward_data_only = flag
        if self.forward_data_only:
            self.forward_net_only = False

    def set_forward_net_only(self, flag):
        self.forward_net_only = flag
        if self.forward_net_only:
            self.forward_data_only = False

    def set_forward_both(self):
        self.forward_data_only = False
        self.forward_net_only = False

    def set_verbose(self, verbose):
        self.verbose = verbose

    def set_phase(self, phase):
        self.phase = phase
        if phase == 'TRAIN':
            self.train()
        else:
            self.eval()

    def set_mean_file(self, mean_file):
        if mean_file != "":
            self.has_mean = True
            self.mean_file = mean_file

        else:
            self.has_mean = False
            self.mean_file = ""

    def get_outputs(self, outputs):
        blobs = []
        for name in outputs:
            blobs.append(self.blobs[name])
        return blobs

    def forward(self, *inputs):
        if self.training:
            self.set_phase('TRAIN')
        else:
            self.set_phase('TEST')

        # TODO: have an option to delete blobs that are not needed, to save memory
        self.blobs = OrderedDict()

        if len(inputs) >= 2:
            data = inputs[0]
            label = inputs[1]
            self.blobs['data'] = data
            self.blobs['label'] = label
            if self.has_mean:
                n_b = data.data.size(0)
                n_c = data.data.size(1)
                n_h = data.data.size(2)
                n_w = data.data.size(3)
                data -= Variable(self.mean_img.view(1, n_c, n_h, n_w).expand(n_b, n_c, n_h, n_w))
        elif len(inputs) == 1:
            data = inputs[0]
            self.blobs['data'] = data
            if self.has_mean:
                n_b = data.data.size(0)
                n_c = data.data.size(1)
                n_h = data.data.size(2)
                n_w = data.data.size(3)
                data -= Variable(self.mean_img.view(1, n_c, n_h, n_w).expand(n_b, n_c, n_h, n_w))

        layers = self.net_info['layers']

        layer_num = len(layers)
        i = 0
        self.output = None
        self.output_loss = None
        while i < layer_num:
            layer = layers[i]
            lname = layer['name']
            if 'include' in layer and 'phase' in layer['include']:
                phase = layer['include']['phase']
                lname = lname + '.' + phase
                if phase != self.phase:
                    i = i + 1
                    continue
            ltype = layer['type']
            if 'top' not in layer:
                continue
            tname = layer['top']
            tnames = tname if type(tname) == list else [tname]
            if ltype in ['Data', 'AnnotatedData', 'TsvBoxData']:
                if (not self.omit_data_layer) and (not self.forward_net_only):
                    tdatas = self._modules[lname]()
                    if type(tdatas) != tuple:
                        tdatas = (tdatas,)

                    assert (len(tdatas) == len(tnames))
                    for index, tdata in enumerate(tdatas):
                        self.blobs[tnames[index]] = tdata
                    if self.verbose:
                        logging.info('forward %-30s produce -> %s' % (
                            lname,
                            self._blob_size(tnames)
                        ))
                i = i + 1
                continue

            if self.forward_data_only:
                break

            bname = layer['bottom']
            bnames = bname if type(bname) == list else [bname]
            bdatas = [self.blobs[name] for name in bnames]
            tdatas = self._modules[lname](*bdatas)
            if type(tdatas) != tuple:
                tdatas = (tdatas,)

            assert (len(tdatas) == len(tnames))
            for index, tdata in enumerate(tdatas):
                self.blobs[tnames[index]] = tdata

            if ltype in ['SoftmaxWithLoss', 'MultiBoxLoss', 'EuclideanLoss', 'SoftmaxTreeWithLoss']:
                if self.output_loss is not None:
                    self.output_loss += tdatas[0]
                else:
                    self.output_loss = tdatas[0]
            i = i + 1
            if self.verbose:
                logging.info('forward %-30s %s -> %s' % (
                    lname,
                    self._blob_size(bnames),
                    self._blob_size(tnames)
                ))

        if self.forward_data_only:
            odatas = [blob for blob in self.blobs.values()]
            return tuple(odatas)

        if self.targets:
            odatas = [self.blobs.get(tname) for tname in self.targets]
            return tuple([d for d in odatas if d is not None])

        if self.output_loss is not None:
            return self.output_loss

    def get_targets(self):
        """Automaticlly get the set of network outputs
        :rtype: set
        """
        layers = self.net_info['layers']
        targets = set()
        for layer in layers:
            if 'top' not in layer:
                # Silence layer perhaps
                continue
            tname = layer['top']
            tnames = tname if type(tname) == list else [tname]
            targets.update(tnames)

        bottoms = set()
        for layer in layers:
            if 'bottom' not in layer:
                continue
            bname = layer['bottom']
            bnames = bname if type(bname) == list else [bname]
            bottoms.update(bnames)
        # tops that are not bottoms
        targets -= bottoms
        del bottoms

        if self.verbose:
            logging.info("Network outputs: {}".format(targets))

        return targets

    def get_loss(self):
        return self.output_loss

    def print_network(self):
        print(self)
        print_prototxt(self.net_info)

    def load_weights(self, caffemodel):
        if self.has_mean:
            logging.info('mean_file', self.mean_file)
            mean_blob = read_blob(self.mean_file)

            if 'input_shape' in self.net_info['props']:
                channels = int(self.net_info['props']['input_shape']['dim'][1])
                height = int(self.net_info['props']['input_shape']['dim'][2])
                width = int(self.net_info['props']['input_shape']['dim'][3])
            else:
                channels = int(self.net_info['props']['input_dim'][1])
                height = int(self.net_info['props']['input_dim'][2])
                width = int(self.net_info['props']['input_dim'][3])

            mu = np.array(mean_blob.data)
            # noinspection PyTypeChecker
            mu.resize(channels, height, width)
            mu = mu.mean(1).mean(1)
            mean_img = torch.from_numpy(mu).view(channels, 1, 1).expand(channels, height, width).float()

            self.register_buffer('mean_img', torch.zeros(channels, height, width))
            self.mean_img.copy_(mean_img)

        model = read_model(caffemodel)
        layers = model.layer
        if len(layers) == 0:
            logging.info('Using V1LayerParameter')
            layers = model.layers

        lmap = {}
        for l in layers:
            lmap[l.name] = l

        layers = self.net_info['layers']
        layer_num = len(layers)
        i = 0
        while i < layer_num:
            layer = layers[i]
            lname = layer['name']
            if 'include' in layer and 'phase' in layer['include']:
                phase = layer['include']['phase']
                lname = lname + '.' + phase
            ltype = layer['type']
            if lname not in lmap:
                i = i + 1
                continue
            if ltype in ['Convolution', 'Deconvolution']:
                logging.info('load weights %s' % lname)
                convolution_param = layer['convolution_param']
                bias = True
                if 'bias_term' in convolution_param and convolution_param['bias_term'] == 'false':
                    bias = False
                caffe_weight = np.array(lmap[lname].blobs[0].data)
                caffe_weight = torch.from_numpy(caffe_weight).view_as(self.models[lname].weight)
                self.models[lname].weight.data.copy_(caffe_weight)
                if bias and len(lmap[lname].blobs) > 1:
                    self.models[lname].bias.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[1].data)))
                i = i + 1
            elif ltype == 'BatchNorm':
                logging.info('load weights %s' % lname)
                self.models[lname].running_mean.copy_(
                    torch.from_numpy(np.array(lmap[lname].blobs[0].data) / lmap[lname].blobs[2].data[0]))
                self.models[lname].running_var.copy_(
                    torch.from_numpy(np.array(lmap[lname].blobs[1].data) / lmap[lname].blobs[2].data[0]))
                i = i + 1
            elif ltype == 'Scale':
                logging.info('load weights %s' % lname)
                self.models[lname].weight.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[0].data)))
                self.models[lname].bias.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[1].data)))
                i = i + 1
            elif ltype == 'Normalize':
                logging.info('load weights %s' % lname)
                self.models[lname].weight.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[0].data)))
                i = i + 1
            elif ltype == 'InnerProduct':
                logging.info('load weights %s' % lname)
                if type(self.models[lname]) == nn.Sequential:
                    self.models[lname][1].weight.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[0].data)))
                    if len(lmap[lname].blobs) > 1:
                        self.models[lname][1].bias.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[1].data)))
                else:
                    self.models[lname].weight.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[0].data)))
                    if len(lmap[lname].blobs) > 1:
                        self.models[lname].bias.data.copy_(torch.from_numpy(np.array(lmap[lname].blobs[1].data)))
                i = i + 1
            else:
                if ltype not in SUPPORTED_LAYERS:
                    logging.error('load_weights: unknown type %s' % ltype)
                i = i + 1

    def create_network(self, net_info,
                       input_batch=None, input_width=None, input_height=None, input_channels=None,
                       raise_unknown=True):
        models = OrderedDict()

        layers = net_info['layers']
        props = net_info['props']
        layer_num = len(layers)

        n, c, h, w = 1, 3, 1, 1
        if input_batch is not None:
            n = input_batch
        if input_channels is not None:
            c = input_channels
        if input_height is not None:
            h = input_height
        if input_width is not None:
            w = input_width
        if 'input_shape' in props:
            n = int(props['input_shape']['dim'][0])
            c = int(props['input_shape']['dim'][1])
            h = int(props['input_shape']['dim'][2])
            w = int(props['input_shape']['dim'][3])

            self.width = int(props['input_shape']['dim'][3])
            self.height = int(props['input_shape']['dim'][2])
        elif 'input_dim' in props:
            n = int(props['input_dim'][0])
            c = int(props['input_dim'][1])
            h = int(props['input_dim'][2])
            w = int(props['input_dim'][3])

            self.width = int(props['input_dim'][3])
            self.height = int(props['input_dim'][2])

        if input_width is not None and input_height is not None:
            w = input_width
            h = input_height
            self.width = input_width
            self.height = input_height
        self.blob_dims['data'] = (n, c, h, w)

        i = 0
        while i < layer_num:
            layer = layers[i]
            lname = layer['name']
            if 'include' in layer and 'phase' in layer['include']:
                phase = layer['include']['phase']
                lname = lname + '.' + phase
            ltype = layer['type']
            if 'top' not in layer:
                assert ltype == 'Silence'
                if raise_unknown:
                    raise NotImplementedError("Silence layer not implemented yet")
                logging.info('create %-20s' % lname)
                if self.verbose:
                    logging.info("Ignore {}({})".format(ltype, lname))
                continue
            tname = layer['top']
            if ltype in ['Data', 'AnnotatedData', 'TsvBoxData']:
                if not self.omit_data_layer:
                    models[lname] = CaffeData(layer.copy(), self.phase)
                    data, label = models[lname].forward()  # forward once just to get the size
                    label_name = None
                    if isinstance(tname, list):
                        data_name = tname[0]
                        if len(tname) > 1:
                            label_name = tname[1]
                    else:
                        data_name = tname
                    # c = len(layer['transform_param']['mean_value'])
                    # h = int(layer['transform_param']['resize_param']['height'])
                    # w = int(layer['transform_param']['resize_param']['width'])
                    self.blob_dims[data_name] = dims = (data.size(0), data.size(1), data.size(2), data.size(3))
                    self.height = dims[2]
                    self.width = dims[3]
                    if label_name:
                        self.blob_dims[label_name] = ([label.size(ii) for ii in range(label.dim())])
                i = i + 1
                logging.info('create %-20s %s' % (
                    lname,
                    self._blob_shape(tname)
                ))
                continue
            bname = layer['bottom']
            if ltype == 'Convolution':
                convolution_param = layer['convolution_param']
                n, c = self.blob_dims[bname][:2]
                out_filters = int(convolution_param['num_output'])
                kernel_size = int(convolution_param['kernel_size'])
                stride = int(convolution_param['stride']) if 'stride' in convolution_param else 1
                pad = int(convolution_param['pad']) if 'pad' in convolution_param else 0
                group = int(convolution_param['group']) if 'group' in convolution_param else 1
                dilation = 1
                if 'dilation' in convolution_param:
                    dilation = int(convolution_param['dilation'])
                bias = True
                if 'bias_term' in convolution_param and convolution_param['bias_term'] == 'false':
                    bias = False
                models[lname] = nn.Conv2d(c, out_filters, kernel_size=kernel_size, stride=stride, padding=pad,
                                          dilation=dilation, groups=group, bias=bias)
                c = out_filters
                w = (self.blob_dims[bname][3] + 2 * pad - kernel_size) / stride + 1
                h = (self.blob_dims[bname][2] + 2 * pad - kernel_size) / stride + 1
                self.blob_dims[tname] = n, c, h, w
                i = i + 1
            elif ltype == 'BatchNorm':
                momentum = 0.9
                if 'batch_norm_param' in layer and 'moving_average_fraction' in layer['batch_norm_param']:
                    momentum = float(layer['batch_norm_param']['moving_average_fraction'])
                n, c, h, w = self.blob_dims[bname]
                models[lname] = nn.BatchNorm2d(c, momentum=momentum, affine=False)
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'Scale':
                n, c, h, w = self.blob_dims[bname]
                models[lname] = Scale(c)
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'ReLU':
                inplace = (bname == tname)
                if 'relu_param' in layer and 'negative_slope' in layer['relu_param']:
                    negative_slope = float(layer['relu_param']['negative_slope'])
                    models[lname] = nn.LeakyReLU(negative_slope=negative_slope, inplace=inplace)
                else:
                    models[lname] = nn.ReLU(inplace=inplace)
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'Pooling':
                kernel_size = int(layer['pooling_param']['kernel_size'])
                stride = int(layer['pooling_param']['stride'])
                padding = 0
                if 'pad' in layer['pooling_param']:
                    padding = int(layer['pooling_param']['pad'])
                pool_type = layer['pooling_param']['pool']
                if pool_type == 'MAX':
                    models[lname] = nn.MaxPool2d(kernel_size, stride, padding=padding, ceil_mode=True)
                elif pool_type == 'AVE':
                    models[lname] = nn.AvgPool2d(kernel_size, stride, padding=padding, ceil_mode=True)

                n, c, h, w = self.blob_dims[bname]
                new_w = int(math.ceil((w + 2 * padding - kernel_size) / float(stride))) + 1
                new_h = int(math.ceil((h + 2 * padding - kernel_size) / float(stride))) + 1
                self.blob_dims[tname] = n, c, new_h, new_w
                i = i + 1
            elif ltype == 'Eltwise':
                operation = 'SUM'
                if 'eltwise_param' in layer and 'operation' in layer['eltwise_param']:
                    operation = layer['eltwise_param']['operation']
                models[lname] = Eltwise(operation)
                self.blob_dims[tname] = self.blob_dims[bname[0]]
                i = i + 1
            elif ltype == 'InnerProduct':
                filters = int(layer['inner_product_param']['num_output'])
                n, c, h, w = self.blob_dims[bname]
                if w != -1 or h != -1:
                    channels = c * h * w
                    models[lname] = nn.Sequential(FCView(), nn.Linear(channels, filters))
                else:
                    models[lname] = nn.Linear(c, filters)
                self.blob_dims[tname] = n, filters, 1, 1
                i = i + 1
            elif ltype == 'Dropout':
                # channels = self.blob_dims[bname][0]
                dropout_ratio = float(layer['dropout_param']['dropout_ratio'])
                models[lname] = nn.Dropout(dropout_ratio, inplace=True)
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'Normalize':
                channels = self.blob_dims[bname][1]
                scale = float(layer['norm_param']['scale_filler']['value'])
                models[lname] = Normalize(channels, scale)
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'Permute':
                orders = layer['permute_param']['order']
                order0 = int(orders[0])
                order1 = int(orders[1])
                order2 = int(orders[2])
                order3 = int(orders[3])
                models[lname] = Permute(order0, order1, order2, order3)
                n, c, h, w = self.blob_dims[bname]
                shape = [n, c, h, w]
                self.blob_dims[tname] = shape[order0], shape[order1], shape[order2], shape[order3]
                i = i + 1
            elif ltype == 'Flatten':
                axis = int(layer['flatten_param'].get('axis', 1))
                assert axis > 0, "Not implemented"
                end_axis = int(layer['flatten_param'].get('end_axis', -1))
                assert end_axis == -1, "Not implemented"
                dims = self.blob_dims[bname]
                assert axis < len(dims)
                models[lname] = Flatten(axis)
                self.blob_dims[tname] = dims[0], np.prod(dims[axis:])
                i = i + 1
            elif ltype == 'Slice':
                axis = int(layer['slice_param'].get('axis', 1))
                assert type(tname == list)
                slice_points = layer['slice_param']['slice_point']
                assert type(slice_points) == list
                assert len(slice_points) == len(tname) - 1
                slice_points = [int(s) for s in slice_points]
                shape = self.blob_dims[bname]
                slice_points.append(shape[axis])
                models[lname] = Slice(axis, slice_points)
                shape = list(shape)
                prev = 0
                for idx, tn in enumerate(tname):
                    shape[axis] = slice_points[idx] - prev
                    self.blob_dims[tn] = tuple(shape)
                    prev = slice_points[idx]
                i = i + 1
            elif ltype == 'Concat':
                axis = int(layer.get('concat_param', {}).get('axis', 1))
                models[lname] = Concat(axis)
                tdims = None
                for bn in bname:
                    dims = list(self.blob_dims[bn])
                    assert axis < len(dims), "btottom: {} axis: {} >= {}".format(bn, axis, len(dims))
                    if tdims is None:
                        tdims = dims
                    else:
                        assert axis < len(tdims), "bottom: {} axis: {} shape changed".format(bn, axis)
                        tdims[axis] += dims[axis]
                self.blob_dims[tname] = tuple(tdims)
                i = i + 1
            elif ltype == 'Crop':
                axis = int(layer['crop_param']['axis'])
                offset = int(layer['crop_param']['offset'])
                models[lname] = Crop(axis, offset)
                self.blob_dims[tname] = self.blob_dims[bname[0]]
                i = i + 1
            elif ltype == 'Deconvolution':
                # models[lname] = nn.UpsamplingBilinear2d(scale_factor=2)
                # models[lname] = nn.Upsample(scale_factor=2, mode='bilinear')
                n, c, h, w = self.blob_dims[bname]
                in_channels = c
                out_channels = int(layer['convolution_param']['num_output'])
                group = int(layer['convolution_param']['group'])
                kernel_w = int(layer['convolution_param']['kernel_w'])
                kernel_h = int(layer['convolution_param']['kernel_h'])
                stride_w = int(layer['convolution_param']['stride_w'])
                stride_h = int(layer['convolution_param']['stride_h'])
                pad_w = int(layer['convolution_param']['pad_w'])
                pad_h = int(layer['convolution_param']['pad_h'])
                kernel_size = (kernel_h, kernel_w)
                stride = (stride_h, stride_w)
                padding = (pad_h, pad_w)
                bias_term = layer['convolution_param']['bias_term'] != 'false'
                models[lname] = nn.ConvTranspose2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride,
                                                   padding=padding, groups=group, bias=bias_term)
                self.blob_dims[tname] = n, out_channels, 2 * h, 2 * w
                i = i + 1
            elif ltype == 'Reshape':
                reshape_dims = layer['reshape_param']['shape']['dim']
                reshape_dims = [int(item) for item in reshape_dims]
                reshape_axis = int(layer['reshape_param'].get('axis', 0))
                reshape_num_axes = int(layer['reshape_param'].get('num_axes', -1))
                assert bname in self.blob_dims, "{}({}) must know the dimensions of {}".format(ltype, lname, bname)
                reshape_dims = _reshape(self.blob_dims[bname], reshape_dims,
                                        axis=reshape_axis, num_axes=reshape_num_axes)
                models[lname] = Reshape(reshape_dims)
                self.blob_dims[tname] = tuple(reshape_dims)
                i = i + 1
            elif ltype == 'Softmax':
                axis = int(layer.get('softmax_param', {}).get('axis', 1))
                models[lname] = nn.Softmax(dim=axis)
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'Sigmoid':
                models[lname] = nn.Sigmoid()
                self.blob_dims[tname] = self.blob_dims[bname]
                i = i + 1
            elif ltype == 'Accuracy':
                models[lname] = Accuracy()
                self.blob_dims[tname] = 1, 1, 1
                i = i + 1
            elif ltype == 'SoftmaxWithLoss':
                loss_weight = float(layer.get('loss_weight', 1))
                models[lname] = SoftmaxWithLoss(loss_weight=loss_weight)
                self.blob_dims[tname] = 1, 1, 1
                i = i + 1
            elif ltype == 'EuclideanLoss':
                assert isinstance(bname, list)
                assert 2 <= len(bname) <= 3
                loss_weight = float(layer.get('loss_weight', 1))
                models[lname] = EuclideanLoss(loss_weight=loss_weight)
                self.blob_dims[tname] = 1, 1, 1
                i = i + 1
            elif ltype == 'RegionTarget':
                assert isinstance(bname, list) and len(bname) == 4
                assert isinstance(tname, list) and len(tname) == 6
                biases = [float(b) for b in layer['region_target_param']['biases']]
                rescore = bool(layer['region_target_param'].get('rescore', 'true') == 'true')
                anchor_aligned_images = layer['region_target_param'].get('anchor_aligned_images', 12800)
                coord_scale = layer['region_target_param'].get('coord_scale', 1.0)
                positive_thresh = layer['region_target_param'].get('positive_thresh', 0.6)
                models[lname] = RegionTarget(
                    biases,
                    rescore=rescore, anchor_aligned_images=anchor_aligned_images, coord_scale=coord_scale,
                    positive_thresh=positive_thresh
                )
                dims = self.blob_dims[bname[0]]
                for ii in range(3):
                    self.blob_dims[tname[ii]] = dims
                for ii in range(3, 6):
                    self.blob_dims[tname[ii]] = self.blob_dims[bname[2]]
                i = i + 1
            elif ltype == 'SoftmaxTreeWithLoss':
                assert isinstance(bname, list) and len(bname) == 2
                tree = layer['softmaxtree_param']['tree']
                loss_weight = float(layer.get('loss_weight', 1))
                ignore_label = layer.get('loss_param', {}).get('ignore_label')
                if ignore_label is not None:
                    ignore_label = int(ignore_label)
                models[lname] = SoftmaxTreeWithLoss(tree, ignore_label=ignore_label, loss_weight=loss_weight)
                self.blob_dims[tname] = self.blob_dims[bname[0]]
                i = i + 1
            else:
                if raise_unknown:
                    raise NotImplementedError('unknown layer type #%s#' % ltype)
                logging.error('unknown layer type #%s#' % ltype)
                i = i + 1
                continue

            logging.info('create %-20s %s -> %s' % (
                lname,
                self._blob_shape(bname),
                self._blob_shape(tname)
            ))

        return models


def main():
    init_logging()
    parser = argparse.ArgumentParser(description='Convert Caffe training to PyTorch.')

    parser.add_argument('-s', '--solver',
                        help='Prototxt solver file for caffe training')
    parser.add_argument('--net',
                        help='Caffenet prototxt file for caffe training')
    parser.add_argument('--weights',
                        help='Caffemodel weights file for finetuning')
    parser.add_argument('--work',
                        help='Working path (where "data" folder is located)',
                        default=".")

    args = parser.parse_args()
    args = vars(args)
    os.environ['GLOG_minloglevel'] = '2'

    with cwd(args['work']):
        caffemodel = args['weights']
        protofile = args['net']
        if protofile:
            assert op.isfile(protofile), "{} does not exist".format(protofile)
        solverfile = args['solver']
        if solverfile:
            net = parse_prototxt(solverfile)
            if not protofile:
                protofile = net.get("train_net") or net.get("net")
                assert op.isfile(protofile), "{} does not exist".format(protofile)

        net = CaffeNet(protofile)
        if caffemodel:
            assert op.isfile(caffemodel), "{} does not exist".format(caffemodel)
            net.load_weights(caffemodel)

    return net


if __name__ == '__main__':
    engine = main()
